﻿unit uDM;

interface

uses
  System.SysUtils, System.Classes, Data.DB, uMcServer, uMcDriverBase, uMcDriverFireDAC,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Error, FireDAC.UI.Intf,
  FireDAC.Phys.Intf, FireDAC.Stan.Def, FireDAC.Stan.Pool, FireDAC.Stan.Async,
  FireDAC.Phys, FireDAC.ConsoleUI.Wait, FireDAC.Comp.Client, FireDAC.Phys.FB,
  FireDAC.Phys.FBDef, FireDAC.Phys.IBBase;

type
  TDM = class(TDataModule)
    FDConnection: TFDConnection;
    FDPhysFBDriverLink: TFDPhysFBDriverLink;
    McDriverFireDAC: TMcDriverFireDAC;
    McServer: TMcServer;
    procedure FDConnectionBeforeConnect(Sender: TObject);
    procedure DataModuleCreate(Sender: TObject);
    procedure DataModuleDestroy(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  DM: TDM;

implementation

{%CLASSGROUP 'System.Classes.TPersistent'}

{$R *.dfm}

procedure TDM.DataModuleCreate(Sender: TObject);
begin
  {$IFDEF Win32}
  FDPhysFBDriverLink.VendorLib := 'C:\Windows\SysWOW64\FBCLIENT.DLL';
  {$ELSE}
  FDPhysFBDriverLink.VendorLib := 'C:\Windows\System32\FBCLIENT.DLL';
  {$ENDIF}
end;

procedure TDM.DataModuleDestroy(Sender: TObject);
begin
  FDConnection.Close;
end;

procedure TDM.FDConnectionBeforeConnect(Sender: TObject);
begin
  FDConnection.Params.Values['Server'] := '127.0.0.1';
  FDConnection.Params.Values['Port'] := '3050';
  FDConnection.Params.Database := 'D:\Magno_Componentes\McComponentes_4.0.0\McComponents_Liberado\Sample_Delphi_4.1.0\Database\DB_SAMPLE_FB4.FDB';
  FDConnection.Params.UserName := 'SYSDBA';
  FDConnection.Params.Password := 'masterkey';
end;

end.
