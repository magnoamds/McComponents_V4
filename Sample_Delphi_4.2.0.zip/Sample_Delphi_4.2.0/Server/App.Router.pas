﻿unit App.Router;

interface

uses
  System.Classes,
  System.SysUtils,
  Horse;

type
  TAppRouter = class
  public
    class procedure Load();
  end;

implementation

uses uDM;

class procedure TAppRouter.Load;
begin
  THorse.Get('/',
    procedure(AReq: THorseRequest; ARes: THorseResponse)
    begin
      ARes.ContentType('text/html')
          .Send(Format('<h1>McServer On-Line - Horse version %s</h1>', [THorse.Version]));
    end);

  THorse.Post('/resource',
    procedure(AReq: THorseRequest; ARes: THorseResponse)
    var
      lStream: TStream;
    begin
      try
        if AReq.Headers.ContainsKey('McContentKind') and
           AReq.Headers.Items['McContentKind'].Equals('ckStream') then
        begin
          lStream := DM.McServer.ProcessRequest(AReq.RawWebRequest.RawContent);
          try
            ARes.SendFile(lStream);
          finally
            FreeAndNil(lStream);
          end;
        end
        else
          ARes.ContentType('application/json')
              .Send(DM.McServer.Resource(AReq.Body));
      except
        on E: exception do
          ARes.Send(E.Message);
      end;
    end);
end;

end.
