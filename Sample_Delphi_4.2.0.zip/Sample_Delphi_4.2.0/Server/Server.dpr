﻿program Server;

{$APPTYPE CONSOLE}

{$R *.res}

uses
  System.Classes,
  System.SysUtils,
  Horse,
  Horse.CORS,
  App.Router in 'App.Router.pas',
  uDM in 'uDM.pas' {DM: TDataModule};

begin
  IsConsole := False;
  ReportMemoryLeaksOnShutdown := True;

  DM := TDM.Create(nil);
  try
    THorse.Use(CORS);

    TAppRouter.Load();

    THorse.Listen(9095,
      procedure
      begin
        WriteLn(Format('Server active on port %d', [THorse.Port]));
        WriteLn('Tecle <ENTER> para finalizar...');
        Readln;
      end);
  finally
    FreeAndNil(DM);
  end;
end.
